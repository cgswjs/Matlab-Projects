function [Ridge_Coef]=RidgeCoef(X_thr,y,lambda)
Is=size(pinv((X_thr')*X_thr));
Ridge_Coef = (pinv((X_thr')*X_thr)+lambda*eye(Is))*X_thr'*y;